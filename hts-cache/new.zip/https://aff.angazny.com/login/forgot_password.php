<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Forgot Password</title>
<link rel="shortcut icon" href="img/shark.svg" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="node_modules/bootstrap/dist/css/bootstrap.min.css">
   <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
<link href="css/call-styles2.css" rel="stylesheet" type="text/css">
<script src="node_modules/jquery/dist/jquery.min.js"></script>
<script src="node_modules/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- <script src="https://www.google.com/recaptcha/api.js"></script> -->
<script src="https://www.google.com/recaptcha/api.js?render=6LeL_rsZAAAAAM-kw-tIZyjaJrw-M4-UoLKL2UEp"></script>

<script>
//    function onSubmit(token) {
// var error="";
// if($("#name").val()==""){
//         error+="Full Name is required<br>"
//     }
//     if($("#name").val()==""){
//         error+="Full Name is required<br>"
//     }

//     $(".modal-message").text(error)
//     $('#myModal').modal('show')


//      //document.getElementById("signup-form").submit();
//    }
 </script>
<script>

        grecaptcha.ready(function() {
          grecaptcha.execute('6LeL_rsZAAAAAM-kw-tIZyjaJrw-M4-UoLKL2UEp', {action: 'submit'}).then(function(token) {
              // Add your logic to submit to your backend server here.
                $(".g-recaptcha-response").val(token)
          });
        });
      
  </script>

</head>

<body>
    <div class="container" style="margin-top: 30px">
        
                <form method="post" id="signup-form" action="">
        <div class="col-md-5 m-auto">
        <div class="form-container Affiliate">
         <div class="login-container">
                         <div class="form-row">
               <div class="col-md-12"><h1 style="font-size: 20px; margin:0 ;text-align: center;">Account recovery </h1></div>
                 
                 
             </div>
             <input type="hidden" value="JDJ5JDEwJEFmTVVGb05DYVZsMkd4S29VYmpEWnVwQmNIbVExTTFXRkg4OTJwR2p4UFYvZnpaeGlYQXVh" name="csrf_token">
                     <label for="E-m"><b>E-mail</b></label>
                    <input type="email" placeholder="Enter your E-mail" name="email"  required value="" >
                    
           </div>
               <div class="button">
    <input type="hidden" name="action" value="submit">
               <input type="hidden" name="g-recaptcha-response" class="g-recaptcha-response" >    
               <button type="submit" name="Sumbit" style="margin: 15px 0 0;" >submit</button></div>
        </div>
        </div>
        </form>
            </div>

       
</body>
</html>